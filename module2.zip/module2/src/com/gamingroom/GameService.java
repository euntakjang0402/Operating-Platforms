package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine.
 *
 * @author coce@snhu.edu
 */
public class GameService {

    /**
     * A list of the active games.
     */
    private static List<Game> games = new ArrayList<Game>();

    /**
     * Holds the next game identifier.
     */
    private static long nextGameId = 1;

    /**
     * Holds the next player identifier.
     */
    private static long nextPlayerId = 1;

    /**
     * Holds the next team identifier.
     */
    private static long nextTeamId = 1;

    // Create a private variable to track the existence of GameService.
    private static GameService service;

    // Default constructor.
    private GameService() {
    }

    /**
     * Check for the existing instance of GameService.
     *
     * @return the single instance of GameService (either new or existing).
     */
    public static GameService getInstance() {

        // Check if the GameService instance exists.
        if (service == null) {
            // If not, create a new instance in heap memory.
            service = new GameService();
            System.out.println("New Game Service created.");
        } else {
            // If it already exists, just print a message.
            System.out.println("Game Service already instantiated.");
        }

        // Return the single instance of GameService (either new or existing).
        return service;
    }

    /**
     * Construct a new game instance or return the existing one if it already exists.
     *
     * @param name the unique name of the game.
     * @return the game instance (new or existing).
     */
    public Game addGame(String name) {

        // Declare a local game instance.
        Game game = null;

        // Create an instance of an iterator for the games list.
        Iterator<Game> gamesIterator = games.iterator();

        // Iterate over the list of games.
        while (gamesIterator.hasNext()) {

            // Set the local Game variable to the next item in the list.
            Game gameInstance = gamesIterator.next();

            // Check if the game name already exists.
            if (gameInstance.getName().equalsIgnoreCase(name)) {
                // If the game name already exists, return the existing game instance.
                return gameInstance;
            }
        }

        // If the game is not found, create a new game instance and add it to the list of games.
        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        // Return the new or existing game instance to the caller.
        return game;
    }

    /**
     * Returns the game instance with the specified id.
     *
     * @param id unique identifier of the game to search for.
     * @return the requested game instance.
     */
    public Game getGame(long id) {

        // Declare a local game instance.
        Game game = null;

        // Create an instance of an iterator for the games list.
        Iterator<Game> gamesIterator = games.iterator();

        // Iterate over the list of games.
        while (gamesIterator.hasNext()) {

            // Set the local Game variable to the next item in the list.
            Game gameInstance = gamesIterator.next();

            // Check if the game id already exists.
            if (gameInstance.getId() == id) {
                // If the game id already exists, return the existing game instance.
                return gameInstance;
            }
        }

        return game;
    }


/**
* Returns the number of games currently active
*
* @return the number of games currently active
*/
	public int getGameCount() {
		return games.size();
}

/**
* Returns the player whose turn is next
*
* @return the player whose turn is next
*/
	public long getNextPlayerId() {
		return nextPlayerId;
}

/**
* Returns the team whose turn is next
*
* @return the team whose turn is next
*/
	public long getNextTeamId() {
		return nextTeamId;
}
}