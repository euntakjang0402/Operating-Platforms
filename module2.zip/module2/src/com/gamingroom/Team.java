package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * This class extends the Entity class and contains information about a team.
 * It has an overloaded constructor that requires an id and name to be passed as arguments when creating an instance of the class.
 * Also, note that there are no mutators (setters) defined in the class, so these values cannot be changed once a team is created.
 * </p>
 * @author coce@snhu.edu
 */
public class Team extends Entity{

/**
 * A list of the active players in the team
 */
private List<Player> players = new ArrayList<Player>();

/**
 * Constructor with an identifier and name
 * @param id the id of the team
 * @param name the name of the team
 */
public Team(long id, String name) {
  super(id, name);
}

/**
 * Uses iterator pattern to find an existing player with the same name or
 * adds a new player with a unique name to the list of players
 *
 * @param name the name of the player to add
 * @return Player instance
 */
public Player addPlayer(String name) {
  // a local player instance
  Player player = null;

  // Instance iterator
  Iterator<Player> playersIterator = players.iterator();

  // Iterate over players list
  while (playersIterator.hasNext()) {
    // Set local player var to the next item in the list
    Player playerInstance = playersIterator.next();

    // Check if the player name already exists in the list
    if (playerInstance.getName().equalsIgnoreCase(name)) {
      // If the player name already exists, return the player instance
      player = playerInstance;
    }
      else {
    	  players.add(player);
      }
    }
    return player;
  }

/**
 * Overridden toString method to return a string representation of the team
 * @return a string representation of the team
 */
@Override
public String toString() {
  return "Team [id=" + super.getId() + ", name=" + super.getName() + "]";
}
}
