package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 *
 * <p>
 * This class extends the Entity class, which provides basic information such as id and name.
 * The Game class holds a list of teams and provides a method to add teams to this list.
 * The addTeam method checks if the team name already exists in the list. If it does, the existing team is returned,
 * otherwise a new team with the given name is added to the list and returned.
 * </p>
 *
 * @author coce@snhu.edu
 */
public class Game extends Entity {
    /**
     * A list of active teams in the game
     */
    private List<Team> teams = new ArrayList<>();

    /**
     * Constructor with an identifier and name
     *
     * @param id the unique identifier of the game
     * @param name the name of the game
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a new team to the list of teams, or returns an existing team with the same name
     *
     * @param name the name of the team to add
     * @return the added/existing team
     */
    public Team addTeam(String name) {
        // A local variable to store the team
        Team team = null;

        // Create an iterator for the list of teams
        Iterator<Team> teamsIterator = teams.iterator();

        // Loop through the list of teams
        while (teamsIterator.hasNext()) {
            // Get the next team in the list
            Team teamInstance = teamsIterator.next();

            // Check if the team name already exists in the list
            if (teamInstance.getName().equalsIgnoreCase(name)) {
                // If the team name already exists, set the local team variable to the existing team
                team = teamInstance;
            }
            else {
            	teams.add(team);
            }
        }

        // Return the added/existing team
        return team;
    }

    @Override
    public String toString() {
        return "Game [id=" + super.getId() + ", name=" + super.getName() + "]";
    }
}
