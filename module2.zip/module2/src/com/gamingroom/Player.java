package com.gamingroom;

/**
 * A simple class to hold information about a player.
 * <p>
 * This class features an overloaded constructor that requires
 * an id and name to be passed when creating a new player object.
 * Additionally, there are no mutators (setters) defined, so
 * these values cannot be changed once a player is created.
 * </p>
 *
 * @author coce@snhu.edu
 */
public class Player extends Entity {

    /**
     * Constructor with an identifier and name.
     *
     * @param id   The unique identifier for the player.
     * @param name The name of the player.
     */
    public Player(long id, String name) {
        super(id, name);
    }

    /**
     * Generates a string representation of the player object.
     *
     * @return A string representation of the player, including id and name.
     */
    @Override
    public String toString() {
        return "Player [id=" + super.getId() + ", name=" + super.getName() + "]";
    }
}
