package com.gamingroom;

public class Entity {

    // Private attribute to store unique identifier of the entity
    private long id;
    // Private attribute to store the name of the entity
    private String name;

    // Default constructor
    private Entity() {
    }

    // Custom constructor with id & name parameters
    public Entity(long id, String name) {
        this(); // Call default constructor to initialize the object
        this.id = id; // Set the id attribute with the provided value
        this.name = name; // Set the name attribute with the provided value
    }

    // Getter method for id attribute
    public long getId() {
        return id;
    }

    // Getter method for name attribute
    public String getName() {
        return name;
    }

    // Overridden toString method to return string representation of the Entity object
    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}
